from backend.agents.base_agent import BaseAgent

class MotivationAgent(BaseAgent):
    def __init__(self):
        super().__init__("motivation_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        goal = user_data.get("goal", "Build Strength")
        fitness_level = user_data.get("fitness_level", "Intermediate")
        duration = user_data.get("duration", 20)
        
        profile_summary = ""
        safety_concerns = ""
        
        if previous_outputs:
            if "profile_agent" in previous_outputs:
                profile_summary = previous_outputs["profile_agent"].get("summary", "")
            if "safety_agent" in previous_outputs:
                safety_concerns = ", ".join(previous_outputs["safety_agent"].get("safety_concerns", []))

        prompt = f"""
        You are the Motivation Agent.
        Your responsibility is to formulate a supportive motivational quote, an encouraging comment (considering the safety concerns or restrictions), a next-day workout teaser, and estimate key metrics.
        
        User Goal: {goal}
        Fitness Level: {fitness_level}
        Duration: {duration} minutes
        Profile Summary: {profile_summary}
        Safety Concerns: {safety_concerns}

        Return a JSON object with the following fields:
        1. "daily_motivation": A powerful, inspirational fitness quote or saying.
        2. "encouragement_message": A personalized message of encouragement referencing their target goal and highlighting their safety constraints (e.g. "We've modified your plan for knee comfort, ensuring you stay active safely!").
        3. "next_day_preview": A short teaser for what they should do tomorrow (e.g. "Mobility work and active recovery").
        4. "estimated_calories": Estimated calories burned during this specific workout as an integer (e.g. 150 or 280).
        5. "difficulty_level": Session difficulty adjusted to their profile (Beginner, Intermediate, or Advanced).
        6. "recovery_time_hours": Estimated hours of recovery needed (integer, e.g. 24 or 48).

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
