from backend.agents.base_agent import BaseAgent
from backend.utils.mcp_tools import lookup_safe_alternatives

class SafetyAgent(BaseAgent):
    def __init__(self):
        super().__init__("safety_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        health_concerns = user_data.get("health_concerns", [])
        concerns_str = ", ".join(health_concerns) if health_concerns else "None"
        
        # Look up safe alternatives for reference exercises if the user has concerns
        pre_loaded_alternatives = {}
        target_exercises = ["Heavy Deadlifts", "Barbell Squats", "Weighted Twists", "Jumping Lunges", "Box Jumps", "Deep Barbell Squats", "Overhead Pressing", "Standard Push-ups", "Barbell Bench Press"]
        
        for exercise in target_exercises:
            res = lookup_safe_alternatives(exercise)
            if res["is_contraindicated"]:
                pre_loaded_alternatives[exercise] = res["safe_alternative"]

        prompt = f"""
        You are the Safety Agent.
        The user has selected the following health concerns: {concerns_str}.

        Here is a set of known contraindicated movements and their safe alternatives from our Safety Database:
        {pre_loaded_alternatives}

        Your responsibility is to analyze the user's concerns, identify contraindicated (unsafe) exercises that they should avoid, suggest safer alternatives for those movements, and draft precaution rules. Use the safety database above to inform your response.

        Return a JSON object with the following fields:
        1. "safety_concerns": A list of short summaries detailing how the listed concerns affect physical capacity.
        2. "contraindicated_exercises": A list of exercises the user MUST avoid (e.g. ["Barbell squats", "Overhead press"] if they have knee/shoulder pain).
        3. "safe_alternatives": A JSON object mapping each contraindicated exercise to its safe alternative (e.g. {{"Barbell squats": "Bodyweight glute bridges", "Overhead press": "Dumbbell lateral raises below shoulder level"}}).
        4. "general_precaution_notes": A string outlining key warm-up advice or form rules to prevent injury (e.g. "Do not arch lower back; keep joints warm").

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
