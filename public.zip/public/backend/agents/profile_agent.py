from backend.agents.base_agent import BaseAgent
from backend.utils.mcp_tools import calculate_health_metrics

class ProfileAgent(BaseAgent):
    def __init__(self):
        super().__init__("profile_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        name = user_data.get("name", "Athlete")
        age = user_data.get("age", 25)
        gender = user_data.get("gender", "Male")
        fitness_level = user_data.get("fitness_level", "Intermediate")
        activity_level = user_data.get("activity_level", "Moderate")
        
        # Calculate baseline metrics using the MCP Tool
        metrics = calculate_health_metrics(age=age, gender=gender, activity_level=activity_level)
        bmr = metrics["bmr_kcal"]
        tdee = metrics["tdee_kcal"]
        water = metrics["recommended_water_intake_liters"]
        protein = metrics["recommended_protein_intake_grams"]
        
        prompt = f"""
        Analyze the following user profile for fitness assessment.
        Name: {name}
        Age: {age}
        Gender: {gender}
        Fitness Level: {fitness_level}
        Daily Activity Level: {activity_level}

        Deterministically calculated baselines (reference these in your assessment):
        - BMR: {bmr} kcal
        - TDEE: {tdee} kcal
        - Hydration Target: {water} Liters
        - Protein Target: {protein} grams

        You are the Profile Analysis Agent. Your responsibility is to analyze demographic details and activity levels to establish baseline physiological guidelines.
        
        Return a JSON object with the following fields:
        1. "summary": A brief, professional profile summary of the user (2-3 sentences), mentioning the assessed baseline metabolic needs.
        2. "estimated_recovery_rate": Estimated physical recovery capacity (High, Moderate, or Low).
        3. "physiological_considerations": A list of 3 important age/gender/level-related physiological observations or recommendations.

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
