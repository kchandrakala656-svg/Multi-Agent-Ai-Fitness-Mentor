from backend.agents.base_agent import BaseAgent
from backend.utils.mcp_tools import recommend_workouts
import json

class WorkoutAgent(BaseAgent):
    def __init__(self):
        super().__init__("workout_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        duration = user_data.get("duration", 20)
        goal = user_data.get("goal", "Build Strength")
        fitness_level = user_data.get("fitness_level", "Intermediate")
        
        # Call the MCP tool
        baseline_workout = recommend_workouts(goal, duration, fitness_level)
        
        # Extract details from previous agents
        profile_summary = ""
        goal_strategy = ""
        safety_rules = ""
        
        if previous_outputs:
            if "profile_agent" in previous_outputs:
                profile_summary = previous_outputs["profile_agent"].get("summary", "")
            if "goal_agent" in previous_outputs:
                goal_strategy = previous_outputs["goal_agent"].get("strategy", "")
            if "safety_agent" in previous_outputs:
                safety_data = previous_outputs["safety_agent"]
                safety_rules = f"Avoid: {safety_data.get('contraindicated_exercises', [])}. Alternatives to use: {safety_data.get('safe_alternatives', {})}. Precautions: {safety_data.get('general_precaution_notes', '')}"

        prompt = f"""
        You are the Workout Generation Agent.
        Your responsibility is to design a personalized workout plan including Warm-up, Main Workout, and Cool-down.
        
        Target Session Duration: {duration} minutes
        Fitness Goal: {goal}
        Fitness Level: {fitness_level}
        
        Here is the deterministically recommended baseline program from our Workout Database:
        {json.dumps(baseline_workout, indent=2)}

        Context from other agents:
        - Profile Analysis: {profile_summary}
        - Goal Planning: {goal_strategy}
        - Safety Constraints: {safety_rules}
        
        Structure the plan such that:
        - It fits within the {duration}-minute target (10 minutes -> 3 exercises, 20 minutes -> 4 exercises, 30 minutes -> 5 exercises).
        - It complies with all Safety Constraints. Replace any dangerous movements with their safe alternatives mentioned in safety constraints.
        - Every exercise has clear, descriptive, safety-focused instructions.
        
        Return a JSON object with the following fields:
        1. "warmup": A list of exercises (approx 2-3) to perform as warm-up. Each exercise must be an object with keys: "name", "duration_or_reps", and "instruction".
        2. "workout": A list of exercises (approx 3-5) to perform as main workout. Each exercise must be an object with keys: "name", "duration_or_reps", and "instruction".
        3. "cooldown": A list of recovery stretches (approx 2-3). Each exercise must be an object with keys: "name", "duration_or_reps", and "instruction".

        Example format:
        {{
            "warmup": [
                {{"name": "Dynamic Arm Swings", "duration_or_reps": "30 seconds", "instruction": "Swing arms wide..."}}
            ],
            "workout": [
                {{"name": "Dumbbell Floor Press", "duration_or_reps": "3 sets of 10 reps", "instruction": "Lying flat on floor..."}}
            ],
            "cooldown": [
                {{"name": "Child's Pose", "duration_or_reps": "1 minute", "instruction": "Kneel and stretch..."}}
            ]
        }}

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
