from backend.utils.gemini_client import generate_content_with_fallback

class BaseAgent:
    """
    Base Agent class that defines the core structure for all AI agents.
    """
    def __init__(self, name: str):
        self.name = name

    def run(self, user_data: dict, previous_outputs: dict = None) -> dict:
        """
        Executes the agent's logic by generating a prompt, querying Gemini (or Mock),
        and returning the formatted output.
        """
        prompt = self.generate_prompt(user_data, previous_outputs)
        # Call gemini utility with prompt and user data
        response = generate_content_with_fallback(self.name, prompt, user_data, previous_outputs)
        return response

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        """
        Generates the prompt. Should be overridden by child classes.
        """
        raise NotImplementedError("Each agent must implement the generate_prompt method.")
