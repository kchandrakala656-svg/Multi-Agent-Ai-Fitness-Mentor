from backend.agents.base_agent import BaseAgent

class GoalAgent(BaseAgent):
    def __init__(self):
        super().__init__("goal_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        goal = user_data.get("goal", "Build Strength")
        profile_summary = ""
        if previous_outputs and "profile_agent" in previous_outputs:
            profile_summary = previous_outputs["profile_agent"].get("summary", "")

        prompt = f"""
        You are the Goal Planning Agent.
        The user's selected fitness goal is: {goal}.
        The Profile Analysis Agent evaluated the user as:
        {profile_summary}

        Your responsibility is to decide the workout strategy, target intensity zones, and weekly split patterns matching this goal and physiological outline.

        Return a JSON object with the following fields:
        1. "strategy": A brief strategy description of how to approach this goal (2 sentences).
        2. "intensity_zone": Recommended heart rate or lift intensity zone (e.g. "60-70% Heart Rate Max" or "75-80% 1RM").
        3. "weekly_split_recommendation": Recommended weekly session structure (e.g. "3-Day Full Body Conditioning" or "4-Day Upper/Lower Split").

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
