from backend.agents.base_agent import BaseAgent

class NutritionAgent(BaseAgent):
    def __init__(self):
        super().__init__("nutrition_agent")

    def generate_prompt(self, user_data: dict, previous_outputs: dict = None) -> str:
        goal = user_data.get("goal", "Build Strength")
        age = user_data.get("age", 25)
        gender = user_data.get("gender", "Male")
        activity_level = user_data.get("activity_level", "Moderate")
        
        profile_summary = ""
        workout_plan = ""
        
        if previous_outputs:
            if "profile_agent" in previous_outputs:
                profile_summary = previous_outputs["profile_agent"].get("summary", "")
            if "workout_agent" in previous_outputs:
                # Summarize workout names
                exercises = [ex["name"] for ex in previous_outputs["workout_agent"].get("workout", [])]
                workout_plan = ", ".join(exercises)

        prompt = f"""
        You are the Nutrition Agent.
        Your responsibility is to recommend dietary guidelines, hydration targets, protein counts, and recovery advice to complement the user's workout routine.
        
        Goal: {goal}
        Profile Summary: {profile_summary}
        Current Workout Plan: {workout_plan}

        Return a JSON object with the following fields:
        1. "water_intake_liters": Recommended daily water intake in liters (e.g. 2.8 or 3.5).
        2. "protein_recommendation_grams": Recommended daily protein intake in grams (e.g. 120 or 150).
        3. "meal_suggestions": A JSON object with:
            - "pre_workout": Meal or snack suggestion before exercise.
            - "post_workout": Meal suggestion after exercise.
            - "snacks": Healthy snack suggestion during the day.
        4. "recovery_advice": A short paragraph or advice list for muscle recovery, soreness prevention, or sleep.

        Remember, output ONLY valid JSON, do not include any markdown styling.
        """
        return prompt
