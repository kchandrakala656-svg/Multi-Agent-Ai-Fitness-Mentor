#!/usr/bin/env python
# Console interface for the Fitness Mentor Multi-Agent Swarm
import argparse
import sys
import os
import json

# Adjust path to allow imports from parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.services.orchestrator import Orchestrator

def main():
    parser = argparse.ArgumentParser(description="Multi-Agent AI Fitness Mentor Console Workspace")
    parser.add_argument("--name", type=str, default="Athlete", help="User's name")
    parser.add_argument("--age", type=int, default=25, help="User's age")
    parser.add_argument("--gender", type=str, default="Male", choices=["Male", "Female", "Other"], help="User's gender")
    parser.add_argument("--level", type=str, default="Intermediate", choices=["Beginner", "Intermediate", "Advanced"], help="Fitness level")
    parser.add_argument("--activity", type=str, default="Moderate", choices=["Light", "Moderate", "Active"], help="Daily activity level")
    parser.add_argument("--duration", type=int, default=20, help="Workout session duration (minutes)")
    parser.add_argument("--goal", type=str, default="Build Strength", choices=["Build Strength", "Improve Flexibility", "Boost Energy", "Manage Weight"], help="Fitness goal")
    parser.add_argument("--concerns", type=str, default="None", help="Comma-separated health concerns (e.g. 'Knee Pain,Back Pain')")

    args = parser.parse_args()

    # Parse concerns
    health_concerns = [c.strip() for c in args.concerns.split(",") if c.strip() and c.strip().lower() != "none"]

    user_data = {
        "name": args.name,
        "age": args.age,
        "gender": args.gender,
        "fitness_level": args.level,
        "activity_level": args.activity,
        "duration": args.duration,
        "goal": args.goal,
        "health_concerns": health_concerns
    }

    print("=" * 60)
    print("      MULTI-AGENT AI FITNESS MENTOR SWARM WORKSPACE      ")
    print("=" * 60)
    print(f"Name: {args.name} | Age: {args.age} | Gender: {args.gender}")
    print(f"Goal: {args.goal} | Level: {args.level} | Duration: {args.duration} mins")
    print(f"Activity Index: {args.activity} | Health Concerns: {health_concerns or 'None'}")
    print("-" * 60)
    print("Initializing Agent pipeline Consensus Orchestration...")
    
    orchestrator = Orchestrator()
    results = orchestrator.run_pipeline(user_data)
    
    print("\n" + "=" * 60)
    print("                 FITNESS CONVERGENCE REPORT              ")
    print("=" * 60)

    # 1. Profile Agent output
    profile_data = results.get("profile_agent", {})
    if "error" not in profile_data:
        print("\n[👤 PROFILE AGENT REPORT]")
        print(f"  Summary: {profile_data.get('summary', 'N/A')}")
        print(f"  Recovery Rate: {profile_data.get('estimated_recovery_rate', 'N/A')}")
        print("  Physiological Considerations:")
        for idx, obs in enumerate(profile_data.get("physiological_considerations", []), 1):
            print(f"    {idx}. {obs}")
    else:
        print(f"\n[👤 PROFILE AGENT] Error: {profile_data['error']}")

    # 2. Goal Agent output
    goal_data = results.get("goal_agent", {})
    if "error" not in goal_data:
        print("\n[🎯 GOAL AGENT REPORT]")
        print(f"  Strategy: {goal_data.get('strategy', 'N/A')}")
        print(f"  Intensity Zone: {goal_data.get('intensity_zone', 'N/A')}")
        print(f"  Weekly Split Rec: {goal_data.get('weekly_split_recommendation', 'N/A')}")
    else:
        print(f"\n[🎯 GOAL AGENT] Error: {goal_data['error']}")

    # 3. Safety Agent output
    safety_data = results.get("safety_agent", {})
    if "error" not in safety_data:
        print("\n[🛡️ SAFETY AGENT REPORT]")
        print("  Contraindicated Exercises (MUST AVOID):")
        for ex in safety_data.get("contraindicated_exercises", []):
            print(f"    - {ex}")
        print("  Recommended Safe Alternatives:")
        safe_alts = safety_data.get("safe_alternatives", {})
        for orig, alt in safe_alts.items():
            print(f"    * Replace '{orig}' with '{alt}'")
        print(f"  Precaution Rules: {safety_data.get('general_precaution_notes', 'N/A')}")
    else:
        print(f"\n[🛡️ SAFETY AGENT] Error: {safety_data['error']}")

    # 4. Workout Agent output
    workout_data = results.get("workout_agent", {})
    if "error" not in workout_data:
        print("\n[💪 WORKOUT AGENT PLAN]")
        
        print("  --- Warm-up Routine ---")
        for ex in workout_data.get("warmup", []):
            print(f"    * {ex.get('name')} ({ex.get('duration_or_reps')})")
            print(f"      Instruction: {ex.get('instruction')}")
            
        print("\n  --- Main Workout Circuit ---")
        for ex in workout_data.get("workout", []):
            print(f"    * {ex.get('name')} ({ex.get('duration_or_reps')})")
            print(f"      Instruction: {ex.get('instruction')}")
            
        print("\n  --- Cool-down Stretches ---")
        for ex in workout_data.get("cooldown", []):
            print(f"    * {ex.get('name')} ({ex.get('duration_or_reps')})")
            print(f"      Instruction: {ex.get('instruction')}")
    else:
        print(f"\n[💪 WORKOUT AGENT] Error: {workout_data['error']}")

    # 5. Nutrition Agent output
    nutrition_data = results.get("nutrition_agent", {})
    if "error" not in nutrition_data:
        print("\n[🍎 NUTRITION AGENT PLAN]")
        print(f"  Target Hydration: {nutrition_data.get('water_intake_liters', 'N/A')} Liters / day")
        print(f"  Target Protein: {nutrition_data.get('protein_recommendation_grams', 'N/A')} grams / day")
        print("  Meal Outline:")
        meals = nutrition_data.get("meal_suggestions", {})
        for meal_type, desc in meals.items():
            print(f"    * {meal_type.replace('_', ' ').capitalize()}: {desc}")
        print(f"  Recovery Advice: {nutrition_data.get('recovery_advice', 'N/A')}")
    else:
        print(f"\n[🍎 NUTRITION AGENT] Error: {nutrition_data['error']}")

    # 6. Motivation Agent output
    motivation_data = results.get("motivation_agent", {})
    if "error" not in motivation_data:
        print("\n[🔥 MOTIVATION AGENT BOOSTER]")
        print(f"  Daily Quote: \"{motivation_data.get('daily_motivation', 'N/A')}\"")
        print(f"  Encouragement: {motivation_data.get('encouragement_message', 'N/A')}")
        print(f"  Estimated Calorie Burn: {motivation_data.get('estimated_calories', 'N/A')} kcal")
        print(f"  Workout Difficulty: {motivation_data.get('difficulty_level', 'N/A')}")
        print(f"  Recovery Time: {motivation_data.get('recovery_time_hours', 'N/A')} hours")
    else:
        print(f"\n[🔥 MOTIVATION AGENT] Error: {motivation_data['error']}")

    print("\n" + "=" * 60)
    print("                     END OF REPORT                       ")
    print("=" * 60)

if __name__ == "__main__":
    main()
