import os
from dotenv import load_dotenv

# Load environmental variables from .env file
load_dotenv()

class Config:
    PORT = int(os.environ.get("PORT", 5000))
    FLASK_ENV = os.environ.get("FLASK_ENV", "development")
    DEBUG = FLASK_ENV == "development"
    
    # Gemini configurations
    GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
    # Default to Gemini 1.5 Flash for speed and structured outputs
    GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-1.5-flash")
