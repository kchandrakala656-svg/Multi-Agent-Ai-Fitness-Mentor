import logging
from backend.agents.profile_agent import ProfileAgent
from backend.agents.goal_agent import GoalAgent
from backend.agents.safety_agent import SafetyAgent
from backend.agents.workout_agent import WorkoutAgent
from backend.agents.nutrition_agent import NutritionAgent
from backend.agents.motivation_agent import MotivationAgent

logger = logging.getLogger(__name__)

class Orchestrator:
    """
    Orchestrates the multi-agent execution pipeline:
    Profile -> Goal -> Safety -> Workout -> Nutrition -> Motivation
    """
    def __init__(self):
        self.agents = {
            "profile_agent": ProfileAgent(),
            "goal_agent": GoalAgent(),
            "safety_agent": SafetyAgent(),
            "workout_agent": WorkoutAgent(),
            "nutrition_agent": NutritionAgent(),
            "motivation_agent": MotivationAgent()
        }

    def run_pipeline(self, user_data: dict) -> dict:
        """
        Runs all fitness agents sequentially, gathering accumulated outputs
        to feed into downstream agents.
        """
        logger.info("Starting Multi-Agent Fitness Plan generation pipeline...")
        results = {}
        
        pipeline = [
            "profile_agent",
            "goal_agent",
            "safety_agent",
            "workout_agent",
            "nutrition_agent",
            "motivation_agent"
        ]
        
        for agent_name in pipeline:
            try:
                logger.info(f"Running agent: {agent_name}...")
                agent = self.agents[agent_name]
                # Execute agent with user details and outputs from all previous agents
                results[agent_name] = agent.run(user_data, results)
                logger.info(f"Agent {agent_name} completed successfully.")
            except Exception as e:
                logger.error(f"Error executing agent {agent_name}: {e}")
                # Provide a basic fallback for safety to avoid breaking the pipeline
                results[agent_name] = {"error": str(e)}
                
        logger.info("Multi-Agent Fitness Plan generation completed.")
        return results
