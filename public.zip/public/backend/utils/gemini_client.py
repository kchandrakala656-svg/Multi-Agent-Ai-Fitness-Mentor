import json
import logging
import random
from backend.config import Config
from backend.utils.mcp_tools import calculate_health_metrics, lookup_safe_alternatives, recommend_workouts

# Configure logger
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Try to initialize the Gemini API library
gemini_available = False
try:
    import google.generativeai as genai
    if Config.GEMINI_API_KEY:
        genai.configure(api_key=Config.GEMINI_API_KEY)
        gemini_available = True
        logger.info("Gemini API configured successfully.")
    else:
        logger.warning("No GEMINI_API_KEY found. Running in Mock Fallback mode.")
except ImportError:
    logger.warning("google-generativeai package not found. Running in Mock Fallback mode.")


def generate_content_with_fallback(agent_name, prompt, user_data=None, previous_outputs=None):
    """
    Sends the prompt to the Gemini API if available and configured.
    Otherwise, falls back to generating a realistic, customized mock JSON response.
    """
    if gemini_available:
        try:
            logger.info(f"Invoking Gemini API for agent: {agent_name}")
            model = genai.GenerativeModel(Config.GEMINI_MODEL)
            # Instruct Gemini to return clean, valid JSON
            system_instruction = (
                "You are an expert AI fitness advisor. "
                "You must respond ONLY with a valid, clean JSON object. "
                "Do not wrap your output in markdown backticks or block formatting like ```json ... ```. "
                "Do not include any text before or after the JSON."
            )
            
            response = model.generate_content(
                contents=prompt,
                generation_config={
                    "response_mime_type": "application/json"
                }
            )
            
            # Clean response text in case it still has markdown markers
            text = response.text.strip()
            if text.startswith("```"):
                # strip out markdown block
                lines = text.split("\n")
                if lines[0].startswith("```"):
                    lines = lines[1:]
                if lines[-1].startswith("```"):
                    lines = lines[:-1]
                text = "\n".join(lines).strip()
            
            # Verify it's valid JSON
            parsed = json.loads(text)
            logger.info(f"Gemini API call succeeded for agent: {agent_name}")
            return parsed
            
        except Exception as e:
            logger.error(f"Gemini API call failed: {e}. Falling back to mock generator.")
            # Fall through to mock generator

    # Mock Generator
    return get_customized_mock_response(agent_name, user_data, previous_outputs)


def get_customized_mock_response(agent_name, user_data, previous_outputs):
    """
    Generates structured, premium, and highly-customized mock responses 
    based on the user's parameters and previous agents' outputs.
    """
    user_data = user_data or {}
    name = user_data.get("name", "Athlete")
    age = int(user_data.get("age", 25))
    gender = user_data.get("gender", "Male")
    fitness_level = user_data.get("fitness_level", "Intermediate")
    activity_level = user_data.get("activity_level", "Moderate")
    health_concerns = user_data.get("health_concerns", [])
    duration = int(user_data.get("duration", 20))
    goal = user_data.get("goal", "Build Strength")
    
    # Clean inputs
    if not health_concerns or "None" in health_concerns or len(health_concerns) == 0:
        has_concerns = False
    else:
        has_concerns = True
        
    logger.info(f"Generating mock response for {agent_name} (Goal: {goal}, Concerns: {health_concerns})")

    if agent_name == "profile_agent":
        # Call the MCP Tool
        metrics = calculate_health_metrics(age=age, gender=gender, activity_level=activity_level)
        bmr = metrics["bmr_kcal"]
        tdee = metrics["tdee_kcal"]
        
        considerations = [
            f"Target daily calorie requirement: approximately {tdee} kcal to support active metabolism.",
            f"Fitness level evaluated as {fitness_level}. Programming structured load progression accordingly.",
            f"Physical recovery index: Good. Program should incorporate adequate rest cycles."
        ]
        if age > 45:
            considerations.append("Age-adjusted cardiovascular and joint mobility protocols are recommended.")
        else:
            considerations.append("Physiologically optimized for standard dynamic recovery schedules.")
            
        return {
            "summary": f"{age}-year old {gender.lower()} presenting a {fitness_level.lower()} fitness background and {activity_level.lower()} daily activity index. Base metabolic rate calculated at {bmr} kcal via Health Metrics MCP tool.",
            "estimated_recovery_rate": "High" if age < 35 and "Active" in activity_level else "Moderate",
            "physiological_considerations": considerations
        }

    elif agent_name == "goal_agent":
        # Customized workout strategies based on Goal
        strategies = {
            "Build Strength": "Progressive overload compound lift cycles. Focus on muscle motor unit recruitment, core stabilization, and structural resistance.",
            "Improve Flexibility": "Deep fascial stretching and restorative mobility flows. Enhance joint range of motion (ROM) and relieve myofascial restrictions.",
            "Boost Energy": "Cardiovascular conditioning, high-intensity interval training (HIIT) structures, and aerobic capacity extension.",
            "Manage Weight": "High-density resistance combined with caloric expenditure circuits. Optimize post-exercise oxygen consumption (EPOC)."
        }
        
        intensities = {
            "Build Strength": "70% - 85% of 1RM (Moderate to High Intensity)",
            "Improve Flexibility": "Low to Moderate Intensity (Focus on deep breath control and tension release)",
            "Boost Energy": "Variable Intensity (Interval cardio peaking at 80% heart rate max)",
            "Manage Weight": "Moderate to High Cardiorespiratory Intensity (Steady state combined with metabolic active rest)"
        }
        
        splits = {
            "Build Strength": "4-Day Upper/Lower Split",
            "Improve Flexibility": "Daily Restorative Flow",
            "Boost Energy": "3-Day Full Body Conditioning",
            "Manage Weight": "3-Day Metabolic Strength + 2-Day LISS"
        }
        
        return {
            "strategy": strategies.get(goal, "Balanced fitness conditioning covering strength and endurance components."),
            "intensity_zone": intensities.get(goal, "Moderate Heart Rate Zone (60-70% HR max)"),
            "weekly_split_recommendation": splits.get(goal, "3-Day Full Body Routine")
        }

    elif agent_name == "safety_agent":
        concerns_text = ", ".join(health_concerns) if has_concerns else "None"
        contraindicated = []
        alternatives = {}
        precautions = "Ensure warm-up is completely performed before adding resistance load."
        
        if "Back Pain" in health_concerns:
            contraindicated.extend(["Heavy Deadlifts", "Barbell Squats", "Weighted Twists", "Toe Touches"])
            alternatives.update({
                "Heavy Deadlifts": "Bodyweight Glute Bridges or Cable Pull-throughs",
                "Barbell Squats": "Goblet Squats (limiting depth to parallel) or Leg Presses",
                "Weighted Twists": "Bird-Dog or Pallof Press"
            })
            precautions += " Maintain neutral lumbar spine. Avoid spinal flexion under load."
            
        if "Knee Pain" in health_concerns:
            contraindicated.extend(["Jumping Lunges", "Box Jumps", "Deep Barbell Squats", "Leg Extensions"])
            alternatives.update({
                "Jumping Lunges": "Reverse Step Lunges (no impact)",
                "Box Jumps": "Step-ups on low platform",
                "Deep Barbell Squats": "Box Squats or Glute Bridges"
            })
            precautions += " Keep knees aligned with toes. Do not allow knees to collapse inward."
            
        if "Shoulder Pain" in health_concerns:
            contraindicated.extend(["Overhead Pressing", "Standard Push-ups", "Barbell Bench Press"])
            alternatives.update({
                "Overhead Pressing": "Dumbbell Lateral Raises (keeping below shoulder level)",
                "Standard Push-ups": "Incline Push-ups or Chest Press on floor",
                "Barbell Bench Press": "Dumbbell Floor Press (restricting elbow depth)"
            })
            precautions += " Pack shoulders back and down. Keep chest elevated during push movements."

        if not contraindicated:
            contraindicated = ["None"]
            alternatives = {"N/A": "Keep monitoring body feedback"}

        return {
            "safety_concerns": [f"Evaluated health markers indicate: {concerns_text}."],
            "contraindicated_exercises": contraindicated,
            "safe_alternatives": alternatives,
            "general_precaution_notes": precautions.strip()
        }

    elif agent_name == "workout_agent":
        # Extract safety adjustments from previous outputs if present
        safety_data = previous_outputs.get("safety_agent", {}) if previous_outputs else {}
        safe_alts = safety_data.get("safe_alternatives", {})
        
        # Get baseline workout from MCP Tool
        recommended = recommend_workouts(goal, duration, fitness_level)
        wu_list = recommended["warmup"]
        cd_list = recommended["cooldown"]
        base_workout = recommended["workout"]
        
        # Apply safety modifications if necessary
        modified_workout = []
        for move in base_workout:
            name_key = move["name"]
            # Look for matches in safe alternatives
            replaced = False
            for unsafe_move, safe_move in safe_alts.items():
                if unsafe_move.lower() in name_key.lower():
                    # Substitute movement
                    modified_workout.append({
                        "name": f"{safe_move} (Safety Modification)",
                        "duration_or_reps": move["duration_or_reps"],
                        "instruction": f"Alternative due to joint comfort: {move['instruction']}"
                    })
                    replaced = True
                    break
            if not replaced:
                modified_workout.append(move)
                
        return {
            "warmup": wu_list,
            "workout": modified_workout,
            "cooldown": cd_list
        }

    elif agent_name == "nutrition_agent":
        weight_est = 75  # kg
        # Call MCP Tool
        metrics = calculate_health_metrics(weight_kg=weight_est, age=age, gender=gender, activity_level=activity_level)
        water = metrics["recommended_water_intake_liters"]
        protein = metrics["recommended_protein_intake_grams"]
        
        meals = {
            "Build Strength": {
                "pre_workout": "Oatmeal with whole milk, sliced banana, and a scoop of whey protein (1-2 hours before).",
                "post_workout": "Grilled chicken breast (150g) with baked sweet potato and steamed green beans.",
                "snacks": "Mixed berries with fat-free Greek yogurt and 30g pumpkin seeds."
            },
            "Improve Flexibility": {
                "pre_workout": "Green smoothie with spinach, avocado, coconut water, and plant protein powder.",
                "post_workout": "Pan-seared salmon with quinoa salad and roasted bell peppers.",
                "snacks": "Apple slices with almond butter."
            },
            "Boost Energy": {
                "pre_workout": "Whole wheat toast with peanut butter and honey, accompanied by green tea.",
                "post_workout": "Brown rice bowl with black beans, avocado, salsa, and lean ground turkey.",
                "snacks": "Hummus with carrots and cucumber sticks."
            },
            "Manage Weight": {
                "pre_workout": "Egg white omelet with spinach and tomatoes, plus a small handful of berries.",
                "post_workout": "Tuna salad salad bowl with spinach, olive oil dressing, and raw pumpkin seeds.",
                "snacks": "Cottage cheese with cucumber slices and cracked black pepper."
            }
        }
        
        return {
            "water_intake_liters": water,
            "protein_recommendation_grams": protein,
            "meal_suggestions": meals.get(goal, meals["Build Strength"]),
            "recovery_advice": "Focus on high-quality sleep cycles. Drink water continuously during workouts. Stretching is key to recovery."
        }

    elif agent_name == "motivation_agent":
        # Estimate calories, recovery, difficulty based on workout size and goal
        c_burn = 120 if duration <= 10 else (220 if duration <= 20 else 340)
        if goal == "Boost Energy" or goal == "Manage Weight":
            c_burn = int(c_burn * 1.25)
            
        quotes = [
            "Your body can stand almost anything. It's your mind that you have to convince.",
            "Success isn't always about greatness. It's about consistency.",
            "The only bad workout is the one that didn't happen.",
            "Believe you can and you're halfway there."
        ]
        
        encouragements = [
            "You are taking massive steps towards a healthier, pain-free body! By listening to your safety warnings, you set up long-term habits.",
            "Incredible dedication today. This custom plan fits your lifestyle. Consistency is your superpower.",
            "You've set the goals, now you're executing. Focus on control, breathing, and form."
        ]
        
        diff = "Beginner" if fitness_level == "Beginner" else ("Intermediate" if fitness_level == "Intermediate" else "Advanced")
        rec_time = 12 if duration <= 10 else (24 if duration <= 20 else 36)
        if fitness_level == "Beginner":
            rec_time += 12

        return {
            "daily_motivation": random.choice(quotes),
            "encouragement_message": random.choice(encouragements),
            "next_day_preview": "Active recovery routine to focus on cardiovascular oxygenation and flexibility.",
            "estimated_calories": c_burn,
            "difficulty_level": diff,
            "recovery_time_hours": rec_time
        }
        
    return {"status": "Unknown agent"}
