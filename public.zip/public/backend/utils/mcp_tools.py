# Core logic for the MCP Tools shared between the API, Swarm Agents, and the MCP Server.
import random

def calculate_health_metrics(weight_kg: float = 75.0, height_cm: float = 175.0, age: int = 25, gender: str = "Male", activity_level: str = "Moderate") -> dict:
    """
    Calculates BMR, TDEE, protein intake targets, and target hydration index.
    """
    # Mifflin-St Jeor Equation
    if gender.lower() == "male":
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
    elif gender.lower() == "female":
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161
    else:
        bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 80 # Neutral baseline

    # Activity multiplier
    multipliers = {
        "light": 1.2,
        "moderate": 1.4,
        "active": 1.6,
        "high": 1.8
    }
    
    act_key = "moderate"
    for k in multipliers:
        if k in activity_level.lower():
            act_key = k
            break
            
    tdee = bmr * multipliers[act_key]
    
    # Target water (35 ml per kg)
    water_liters = round((weight_kg * 35) / 1000, 2)
    
    # Protein goals (1.2 to 2.0g per kg depending on activity)
    protein_mult = 1.6 if act_key == "active" or act_key == "high" else 1.3
    protein_grams = int(weight_kg * protein_mult)

    return {
        "bmr_kcal": int(bmr),
        "tdee_kcal": int(tdee),
        "recommended_water_intake_liters": water_liters,
        "recommended_protein_intake_grams": protein_grams,
        "activity_level_assessed": activity_level
    }

def lookup_safe_alternatives(exercise_name: str) -> dict:
    """
    Returns a safe alternative for a contraindicated exercise.
    """
    database = {
        "heavy deadlifts": "Cable Pull-throughs or Bodyweight Glute Bridges",
        "barbell squats": "Goblet Squats (limited depth) or Leg Presses",
        "weighted twists": "Bird-Dog or Pallof Press",
        "toe touches": "Cat-Cow Stretch (neutral spine)",
        "jumping lunges": "Reverse Step Lunges (low impact)",
        "box jumps": "Step-ups on low platform",
        "deep barbell squats": "Box Squats or Glute Bridges",
        "leg extensions": "Glute Bridges or Hamstring Curls",
        "overhead pressing": "Dumbbell Lateral Raises (below shoulder level)",
        "standard push-ups": "Incline Push-ups or Chest Press on floor",
        "barbell bench press": "Dumbbell Floor Press (elbows flat)"
    }
    
    match = exercise_name.lower().strip()
    result = None
    for k, v in database.items():
        if k in match or match in k:
            result = v
            break
            
    return {
        "original_exercise": exercise_name,
        "is_contraindicated": result is not None,
        "safe_alternative": result or "Perform slowly under light load; consult a physical therapist."
    }

def recommend_workouts(goal: str, duration_mins: int = 20, fitness_level: str = "Intermediate") -> dict:
    """
    Generates tailored, structured warmups, main workouts, and cool-downs.
    """
    warmups = [
        {"name": "Dynamic Arm Circles", "duration_or_reps": "20 seconds", "instruction": "Rotate arms forward and back to activate shoulders."},
        {"name": "Torso Twists", "duration_or_reps": "30 seconds", "instruction": "Gently twist torso left and right with hands on hips."},
        {"name": "Glute Bridges", "duration_or_reps": "12 reps", "instruction": "Squeeze glutes to lift hips off the floor, warming up posterior chain."},
        {"name": "Cat-Cow Stretch", "duration_or_reps": "1 minute", "instruction": "Alternate arching and rounding back to lubricate spine."},
        {"name": "Marching in Place", "duration_or_reps": "1 minute", "instruction": "Lift knees high while pumping arms to raise heart rate."}
    ]
    
    cooldowns = [
        {"name": "Child's Pose", "duration_or_reps": "1 minute", "instruction": "Sit back on heels and extend arms forward on the floor."},
        {"name": "Seated Hamstring Stretch", "duration_or_reps": "30 seconds per side", "instruction": "Extend one leg, hinge at hips and reach towards toes."},
        {"name": "Cobra Stretch", "duration_or_reps": "45 seconds", "instruction": "Lie face down, push upper body up slightly to stretch abs."},
        {"name": "Standing Quad Stretch", "duration_or_reps": "30 seconds per side", "instruction": "Hold ankle behind you while keeping knees together."},
        {"name": "Deep Breathing Recovery", "duration_or_reps": "1 minute", "instruction": "Inhale for 4 seconds, hold for 2, exhale for 6."}
    ]
    
    strength_moves = [
        {"name": "Barbell Squats", "duration_or_reps": "3 sets of 8 reps", "instruction": "Hinge hips back and squat down, keeping weight in heels."},
        {"name": "Standard Push-ups", "duration_or_reps": "3 sets of 10 reps", "instruction": "Lower chest to ground while keeping body in straight plank line."},
        {"name": "Dumbbell Row", "duration_or_reps": "3 sets of 12 reps", "instruction": "Hinge forward, pull dumbbell towards ribcage while squeezing back muscles."},
        {"name": "Overhead Pressing", "duration_or_reps": "3 sets of 8 reps", "instruction": "Press dumbbells overhead while locking core to protect spine."},
        {"name": "Plank Hold", "duration_or_reps": "3 sets of 45 seconds", "instruction": "Maintain straight line from head to heels, squeezing abs and glutes."}
    ]
    
    flexibility_moves = [
        {"name": "Standing Forward Fold", "duration_or_reps": "90 seconds", "instruction": "Hinge from hips, let head hang heavy, hold elbows."},
        {"name": "Pigeon Pose", "duration_or_reps": "1 minute per side", "instruction": "Bring one knee forward, extend other leg straight back, sink hips."},
        {"name": "Butterfly Stretch", "duration_or_reps": "2 minutes", "instruction": "Press soles of feet together, gently press knees down."},
        {"name": "Kneeling Hip Flexor Stretch", "duration_or_reps": "45 seconds per side", "instruction": "Lunge forward onto knee, tuck pelvis to stretch hip flexor."},
        {"name": "Chest Opener Stretch", "duration_or_reps": "1 minute", "instruction": "Clasp hands behind back, extend arms and lift chest."}
    ]
    
    energy_moves = [
        {"name": "Jumping Jacks", "duration_or_reps": "4 sets of 45 seconds", "instruction": "Perform continuous jumps with high tempo to raise heart rate."},
        {"name": "Mountain Climbers", "duration_or_reps": "3 sets of 30 seconds", "instruction": "Drive knees rapidly to chest from a push-up plank position."},
        {"name": "Bodyweight Squats", "duration_or_reps": "3 sets of 20 reps", "instruction": "Squat down and up rapidly while maintaining clean posture."},
        {"name": "High Knees", "duration_or_reps": "3 sets of 40 seconds", "instruction": "Run in place driving knees up high as fast as possible."},
        {"name": "Burpees", "duration_or_reps": "3 sets of 8 reps", "instruction": "Drop to push-up, jump feet back in, and explode into a vertical leap."}
    ]
    
    weight_moves = [
        {"name": "Goblet Squats", "duration_or_reps": "4 sets of 12 reps", "instruction": "Hold dumbbell at chest level, perform slow controlled squats."},
        {"name": "Kettlebell Swings", "duration_or_reps": "3 sets of 15 reps", "instruction": "Hinge at hips, snap forward to swing kettlebell to shoulder level."},
        {"name": "Incline Push-ups", "duration_or_reps": "3 sets of 12 reps", "instruction": "Place hands on bench, lower chest to push-up to engage upper body."},
        {"name": "Jumping Lunges", "duration_or_reps": "3 sets of 10 reps per leg", "instruction": "Lunge forward, explode up and switch legs in mid-air."},
        {"name": "Bicycle Crunches", "duration_or_reps": "3 sets of 20 reps", "instruction": "Rotate torso to bring opposite elbow to knee in smooth bicycle motion."}
    ]

    base_workout = strength_moves
    if "flexibility" in goal.lower() or "stretch" in goal.lower():
        base_workout = flexibility_moves
    elif "energy" in goal.lower() or "cardio" in goal.lower() or "boost" in goal.lower():
        base_workout = energy_moves
    elif "weight" in goal.lower() or "fat" in goal.lower() or "manage" in goal.lower():
        base_workout = weight_moves

    # Scale counts based on duration
    num_ex = 3 if duration_mins <= 10 else (4 if duration_mins <= 20 else 5)
    wu_count = 2 if duration_mins <= 10 else 3
    cd_count = 2 if duration_mins <= 10 else 3

    return {
        "goal_matched": goal,
        "session_duration_minutes": duration_mins,
        "fitness_level_scaled": fitness_level,
        "warmup": warmups[:wu_count],
        "workout": base_workout[:num_ex],
        "cooldown": cooldowns[:cd_count]
    }
