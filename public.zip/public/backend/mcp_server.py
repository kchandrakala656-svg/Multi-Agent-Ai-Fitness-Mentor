# Model Context Protocol (MCP) Server for Fitness Mentor
import json
import sys
import os

# Allow running from parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP
from backend.utils.mcp_tools import calculate_health_metrics, lookup_safe_alternatives, recommend_workouts

# Create FastMCP server instance
mcp = FastMCP("Fitness-Mentor-Server")

@mcp.tool()
def calculate_health(weight_kg: float = 75.0, height_cm: float = 175.0, age: int = 25, gender: str = "Male", activity_level: str = "Moderate") -> str:
    """
    Calculate physiological baseline metrics including BMR, TDEE, target water intake, and protein targets.
    
    Args:
        weight_kg: User weight in kilograms (default 75.0).
        height_cm: User height in centimeters (default 175.0).
        age: User age in years (default 25).
        gender: Male, Female, or Other.
        activity_level: Light, Moderate, or Active.
    """
    metrics = calculate_health_metrics(weight_kg, height_cm, age, gender, activity_level)
    return json.dumps(metrics, indent=2)

@mcp.tool()
def check_exercise_safety(exercise_name: str) -> str:
    """
    Check if an exercise is contraindicated and return a safe alternative if it is.
    
    Args:
        exercise_name: The name of the exercise to verify (e.g. 'Barbell Squats', 'Jumping Jacks').
    """
    safety_check = lookup_safe_alternatives(exercise_name)
    return json.dumps(safety_check, indent=2)

@mcp.tool()
def get_workout_recommendations(goal: str, duration_mins: int = 20, fitness_level: str = "Intermediate") -> str:
    """
    Get warmup, workout, and cool-down routines tailored to a specific fitness goal and duration.
    
    Args:
        goal: The user's fitness goal (e.g. 'Build Strength', 'Improve Flexibility', 'Boost Energy', 'Manage Weight').
        duration_mins: Target duration of the workout session in minutes.
        fitness_level: Beginner, Intermediate, or Advanced.
    """
    workout = recommend_workouts(goal, duration_mins, fitness_level)
    return json.dumps(workout, indent=2)

if __name__ == "__main__":
    # Start the MCP server using standard input/output transport
    mcp.run()
