import sys
import os

# Adjust path to allow absolute imports from parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from flask import Flask, jsonify
from flask_cors import CORS
from backend.config import Config
from backend.routes.workout_routes import workout_bp

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Enable CORS to allow requests from local frontend html files
    CORS(app, resources={r"/api/*": {"origins": "*"}})
    
    # Register the blueprints
    app.register_blueprint(workout_bp, url_prefix='/api')
    
    @app.route('/health', methods=['GET'])
    def health_check():
        return jsonify({
            "status": "healthy",
            "gemini_api_key_set": bool(Config.GEMINI_API_KEY)
        }), 200

    return app

if __name__ == '__main__':
    app = create_app()
    port = Config.PORT
    debug = Config.DEBUG
    print(f"Initializing Multi-Agent Fitness Mentor Backend on port {port} (Debug: {debug})...")
    app.run(host='0.0.0.0', port=port, debug=debug)
