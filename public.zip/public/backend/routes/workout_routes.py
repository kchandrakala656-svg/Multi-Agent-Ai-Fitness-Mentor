from flask import Blueprint, request, jsonify
from backend.services.orchestrator import Orchestrator
import re
import time
import logging

logger = logging.getLogger(__name__)

workout_bp = Blueprint('workout', __name__)
orchestrator = Orchestrator()

# Simple in-memory rate limiter: IP -> list of timestamps
RATE_LIMIT_WINDOW = 60  # seconds
RATE_LIMIT_MAX_REQUESTS = 30
ip_request_history = {}

def check_rate_limit(ip_address: str) -> bool:
    """
    Checks if an IP address has exceeded the rate limit.
    Returns True if allowed, False if blocked.
    """
    current_time = time.time()
    # Initialize history for new IP
    if ip_address not in ip_request_history:
        ip_request_history[ip_address] = []
        
    # Clean up timestamps older than the window
    ip_request_history[ip_address] = [
        t for t in ip_request_history[ip_address] 
        if current_time - t < RATE_LIMIT_WINDOW
    ]
    
    # Check if limit is exceeded
    if len(ip_request_history[ip_address]) >= RATE_LIMIT_MAX_REQUESTS:
        return False
        
    # Record current request
    ip_request_history[ip_address].append(current_time)
    return True

def detect_prompt_injection(text: str) -> bool:
    """
    Scans input text for potential prompt injection patterns.
    Returns True if potential injection is detected.
    """
    if not text:
        return False
        
    injection_patterns = [
        r"ignore\s+(?:all\s+)?previous\s+instructions",
        r"system\s+prompt",
        r"you\s+are\s+now\s+a",
        r"new\s+role",
        r"instead\s+of\s+doing",
        r"bypass\s+restrictions",
        r"forget\s+what\s+you\s+were\s+told",
        r"disregard\s+instructions",
        r"output\s+only\s+the\s+following"
    ]
    
    for pattern in injection_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            logger.warning(f"Potential prompt injection pattern detected: '{pattern}' in text.")
            return True
            
    return False

@workout_bp.route('/generate-plan', methods=['POST'])
def generate_plan():
    """
    Accepts user details, validates them with security guardrails, 
    and runs the Multi-Agent orchestrator to generate a customized fitness plan.
    """
    # 1. Rate Limiting Security Check
    client_ip = request.remote_addr or "unknown_ip"
    if not check_rate_limit(client_ip):
        logger.error(f"Rate limit exceeded for IP: {client_ip}")
        return jsonify({
            "status": "error",
            "message": "Too many requests. Please try again in 1 minute."
        }), 429

    try:
        data = request.get_json()
        if not data or not isinstance(data, dict):
            return jsonify({
                "status": "error",
                "message": "Malformed payload. Request body must be a valid JSON object."
            }), 400
            
        # 2. Strict Input and Schema Validation
        # Validate Name
        name_val = data.get("name")
        if name_val is not None:
            if not isinstance(name_val, str):
                return jsonify({"status": "error", "message": "Invalid field 'name': must be a string."}), 400
            name = name_val.strip()
            # Basic alphanumeric and length validation for safety
            name = re.sub(r"[^\w\s\.-]", "", name)[:50]
        else:
            name = "Athlete"
            
        if detect_prompt_injection(name):
            return jsonify({"status": "error", "message": "Security Alert: Input contains forbidden patterns."}), 400

        # Validate Age
        age_val = data.get("age", 25)
        try:
            age = int(age_val)
            if age <= 0 or age > 120:
                return jsonify({"status": "error", "message": "Invalid field 'age': must be between 1 and 120."}), 400
        except (ValueError, TypeError):
            return jsonify({"status": "error", "message": "Invalid field 'age': must be an integer."}), 400
            
        # Validate Gender
        gender = str(data.get("gender", "Male")).strip()
        if gender not in ["Male", "Female", "Other"]:
            return jsonify({"status": "error", "message": "Invalid field 'gender': must be Male, Female, or Other."}), 400
            
        # Validate Fitness Level
        fitness_level = str(data.get("fitness_level", "Intermediate")).strip()
        if "beginner" in fitness_level.lower():
            fitness_level = "Beginner"
        elif "advanced" in fitness_level.lower():
            fitness_level = "Advanced"
        else:
            fitness_level = "Intermediate"
            
        # Validate Daily Activity Level
        activity_level = str(data.get("activity_level", "Moderate")).strip()
        if "light" in activity_level.lower():
            activity_level = "Light"
        elif "active" in activity_level.lower():
            activity_level = "Active"
        else:
            activity_level = "Moderate"
            
        # Validate Duration
        duration_val = data.get("duration", 20)
        try:
            duration_str = str(duration_val)
            duration = int(''.join(filter(str.isdigit, duration_str)))
            if duration < 5 or duration > 180:
                return jsonify({"status": "error", "message": "Invalid field 'duration': must be between 5 and 180 minutes."}), 400
        except (ValueError, TypeError):
            return jsonify({"status": "error", "message": "Invalid field 'duration': must be an integer."}), 400
            
        # Validate Goal
        goal = str(data.get("goal", "Build Strength")).strip()
        valid_goals = ["Build Strength", "Improve Flexibility", "Boost Energy", "Manage Weight"]
        if goal not in valid_goals:
            matched = False
            for vg in valid_goals:
                if vg.lower() in goal.lower():
                    goal = vg
                    matched = True
                    break
            if not matched:
                return jsonify({"status": "error", "message": f"Invalid field 'goal': must be one of {valid_goals}."}), 400
                
        # Validate Health Concerns
        health_concerns_val = data.get("health_concerns", [])
        if not isinstance(health_concerns_val, list):
            return jsonify({"status": "error", "message": "Invalid field 'health_concerns': must be an array of strings."}), 400
            
        health_concerns = []
        for concern in health_concerns_val:
            if not isinstance(concern, str):
                return jsonify({"status": "error", "message": "Invalid health concern: must be a string."}), 400
            clean_concern = concern.strip()
            if detect_prompt_injection(clean_concern):
                return jsonify({"status": "error", "message": "Security Alert: Input contains forbidden patterns."}), 400
            # Sanitize input
            clean_concern = re.sub(r"[^\w\s\.-]", "", clean_concern)[:50]
            if clean_concern:
                health_concerns.append(clean_concern)
        
        # Build clean user data dict
        user_data = {
            "name": name,
            "age": age,
            "gender": gender,
            "fitness_level": fitness_level,
            "activity_level": activity_level,
            "duration": duration,
            "goal": goal,
            "health_concerns": health_concerns
        }
        
        # Execute the orchestrator
        results = orchestrator.run_pipeline(user_data)
        
        return jsonify({
            "status": "success",
            "user_data": user_data,
            "plan": results
        }), 200
        
    except Exception as e:
        logger.error(f"Error occurred in generate-plan route: {str(e)}", exc_info=True)
        return jsonify({
            "status": "error",
            "message": "An internal system error occurred while generating your plan. Please contact support."
        }), 500
