import unittest
import sys
import os

# Adjust path to import backend correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from backend.services.orchestrator import Orchestrator

class TestMultiAgentSystem(unittest.TestCase):
    def setUp(self):
        self.orchestrator = Orchestrator()
        self.test_user_data = {
            "name": "Jane Doe",
            "age": 30,
            "gender": "Female",
            "fitness_level": "Beginner",
            "activity_level": "Light",
            "duration": 10,
            "goal": "Improve Flexibility",
            "health_concerns": ["Knee Pain"]
        }

    def test_pipeline_execution(self):
        """
        Verify that running the orchestrator pipeline results in a dictionary
        containing valid, well-formed outputs from all 6 agents.
        """
        results = self.orchestrator.run_pipeline(self.test_user_data)
        
        # Verify all agent outputs exist
        self.assertIn("profile_agent", results)
        self.assertIn("goal_agent", results)
        self.assertIn("safety_agent", results)
        self.assertIn("workout_agent", results)
        self.assertIn("nutrition_agent", results)
        self.assertIn("motivation_agent", results)

        # Profile Agent assertions
        profile = results["profile_agent"]
        self.assertIn("summary", profile)
        self.assertIn("estimated_recovery_rate", profile)
        self.assertIn("physiological_considerations", profile)
        self.assertIsInstance(profile["physiological_considerations"], list)

        # Goal Agent assertions
        goal = results["goal_agent"]
        self.assertIn("strategy", goal)
        self.assertIn("intensity_zone", goal)
        self.assertIn("weekly_split_recommendation", goal)

        # Safety Agent assertions
        safety = results["safety_agent"]
        self.assertIn("safety_concerns", safety)
        self.assertIn("contraindicated_exercises", safety)
        self.assertIn("safe_alternatives", safety)
        self.assertIn("general_precaution_notes", safety)
        self.assertIsInstance(safety["safety_concerns"], list)
        self.assertIsInstance(safety["contraindicated_exercises"], list)
        self.assertIsInstance(safety["safe_alternatives"], dict)

        # Workout Agent assertions
        workout = results["workout_agent"]
        self.assertIn("warmup", workout)
        self.assertIn("workout", workout)
        self.assertIn("cooldown", workout)
        self.assertIsInstance(workout["warmup"], list)
        self.assertIsInstance(workout["workout"], list)
        self.assertIsInstance(workout["cooldown"], list)

        # Nutrition Agent assertions
        nutrition = results["nutrition_agent"]
        self.assertIn("water_intake_liters", nutrition)
        self.assertIn("protein_recommendation_grams", nutrition)
        self.assertIn("meal_suggestions", nutrition)
        self.assertIn("recovery_advice", nutrition)
        self.assertIsInstance(nutrition["meal_suggestions"], dict)
        self.assertIn("pre_workout", nutrition["meal_suggestions"])
        self.assertIn("post_workout", nutrition["meal_suggestions"])
        
        # Motivation Agent assertions
        motivation = results["motivation_agent"]
        self.assertIn("daily_motivation", motivation)
        self.assertIn("encouragement_message", motivation)
        self.assertIn("next_day_preview", motivation)
        self.assertIn("estimated_calories", motivation)
        self.assertIn("difficulty_level", motivation)
        self.assertIn("recovery_time_hours", motivation)
        self.assertIsInstance(motivation["estimated_calories"], int)
        self.assertIsInstance(motivation["recovery_time_hours"], int)

if __name__ == "__main__":
    unittest.main()
